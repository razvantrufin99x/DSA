﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace coadadinamica
{
    public class coadadinamicaads
    {
        public element capulcozii;
        public element coadacozii;

        //public bool initializarecoada() { }
        //public bool testcoadagoala() { }
        //public bool introduceincoada(element e) { }
        //public bool extragedincoada(element e) { }
        //public bool valoaredincap(element e) { }

    }
}
