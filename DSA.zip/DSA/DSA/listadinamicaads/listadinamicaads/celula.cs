﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listadinamicaads
{
    public class celula
    {
        public object tipelement;
        public celula prec;
        public celula urm;

    }
}
