﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listadinamicaads
{
    public class listedinamicaads
    {
        public int lungime;
        public celula inceput;
        public celula curent;
        public celula sfarsit;

        /*
         
         *public bool initializarelista(){}
         *public bool  testlistavida(){}
         *public bool  pozitionareinceput(){}
         *public bool  pozitionaresfarsit(){}
         *public bool  testinceput(){}
         *public bool  testsfarsit(){}
         *public bool  urmator(){}
         *public bool  precedent(){}
         *public bool  adaugalasfarsit(ref object x){}
         *public bool  adresainformatie(ref object x){}
         *public bool  modificainformatie(ref object x){}
         *public bool  stergeelement(){}
         *public bool  insereazaelement(ref object x){}
         *public int lungimelista(){}
         */
    }
}
