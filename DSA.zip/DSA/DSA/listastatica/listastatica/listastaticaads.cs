﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listastatica
{
    public class listastaticaads
    {
        public int curent;
        public int sfarsit;
        public static int maxalocat = 1000;
        public object[] ptipelement = new object[maxalocat];

        public bool initializarelista() {
            sfarsit = 0;
            curent = 0;
            return true;
        }

        public bool testlistavida()
        {
            return sfarsit == 0;
        }

        public bool pozitionareinceput()
        {
            if (testlistavida() == true)
            {
                return false;
            }
            else
            {
                curent = 1;
                return true;
            }
        }

        public bool pozitionaresfarsit()
        {
            if (testlistavida() == true)
            {
                return false;
            }
            else
            {
                curent = sfarsit;
                return true;
            }
        }

        public bool testinceput()
        {
            return curent == 1;
        }

        public bool testsfarsit()
        {
            return curent == sfarsit + 1;
        }

        public bool urmator()
        {
            if (testlistavida() == true)
            {
                return false;
            }
            else
            {
                if (curent < sfarsit + 1)
                {
                    curent += 1;
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool precedent()
        {
            if (testlistavida() == true)
            {
                return false;
            }
            else
            {
                if (curent > 0)
                {
                    curent -= 1;
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public bool adaugalasfarsit(ref object x)
        {
            if (sfarsit < maxalocat)
            {
                sfarsit += 1;
                ptipelement[sfarsit] = x;
                return true;
            }
            else
            {
                return false;
            }

        }

        public bool adresainformatie(ref object x)
        {
            if (testlistavida() == true || testsfarsit() == true)
            { 
                return false; 
            }
            else
            {
                x = ptipelement[curent];
                return true;
            }
        }

        public bool modificainformatie(ref object x)
        {
            if (testlistavida() == true || testsfarsit() == true)
            {
                return false;
            }
            else
            {
                 ptipelement[curent] = x;
                return true;
            }
        }

        public bool stergeelement()
        {
            int i;
            if (testlistavida() == true || testsfarsit() == true)
            {
                return false;
            }
            else
            {
                ptipelement[curent] = null;
                if (curent == sfarsit)
                {
                    curent -= 1;
                }
                else
                {
                    for (i = curent; i <= sfarsit - 1; i++)
                    {
                        ptipelement[i] = ptipelement[i + 1];
                        sfarsit -= 1;
                    }
                }
                return true;
            }

        }

        public bool insereazaelement(ref object x)
        {
            int i;
            if (sfarsit < maxalocat)
            {
                for (i = sfarsit; i >= curent; i--)
                {
                    ptipelement[i+1] = ptipelement[i];
                    ptipelement[curent] = x;
                    sfarsit += 1;
                   
                }
                 return true;
            }

            else
                {
                    return false;
                }
       }
        
        
        public int lungimelista()
        {
            return sfarsit;
        }
        
        

    }
}
