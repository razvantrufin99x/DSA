﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arbore
{
    public class arboreads
    {
        public arborevid rad ;

        public static int declafj = 3;
        public static int lginf = 4;
        public static int maxnivele = 20;
        public int k;
        public int ch;
        public string stanga;
        public string dreapta;
        public string vertical;
        public string[,] antet = new string[maxnivele, 4];



        //public bool testarborevid(){}
        //public bool initializeazaarbore(){}
        //public bool construiestearbore(){}
        //public bool distrugeradacina(){}
        //public bool modificainformatie(){}
        //public bool modificastanga(){}
        //public bool modificadreapta(){}
        //public bool adresainformatie(){}
        //public bool subarborestang(){}
        //public bool subarboredrept(){}
        //public bool frunza(){}
        //public bool numarnoduri(){}
        //public bool inaltime(){}
        //public bool cautaresubarbore(){}
        //public bool distrugearbore(){}
        //public bool parcurgeinpreordine(){}
        //public bool parcurgeininordine(){}
        //public bool parcurgeinpostordine(){}
        //public bool parcurgeinadincime(){}
        //public bool parcurgeinlatime(){}
        //public bool prelucrare1(){}
        //public bool prelucrare2(){}
        //public bool proprietate(){}
        //public bool distra(){}
        //public bool distrugeinformatie(){}
        //public bool adaugafrunza(){}
        //public bool constrarborebinar(){}
        //public bool raspuns(){}
        //public bool tpreordine(){}
        //public bool tiparireinpreordine(){}
        //public bool tiparirelg(){}
        //public bool tinordine(){}
        //public bool tiparireininordine(){}
        //public bool egal(){}
        //public bool tiparirecuparantezecomplete(){}

        //public bool relatie(){}
        //public bool inserarenod(){}
        //public bool eliminanod(){}
        //public bool cautanod(){}
        //public bool cautasielimina(){}
        //public bool cautare(){}
        //public bool eg(){}
        //public bool maimic(){}
        //public bool relsubarbore(){}
        //public bool constrarborecautare(){}
        //public bool egal(){}


    }
}
