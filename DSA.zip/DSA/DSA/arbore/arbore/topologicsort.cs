﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arbore
{
    public class topologicsort
    {
        public int multimelemente;
        public static int nemax = 32;
        public int nrelemente;
        public int nrpartialsortate;
        public int[] listasortate = new int[nemax];
        public object[] conditionari = new object[nemax];

        //public bool topsort(){}
        //public bool citireconditionari(){}
    }
}
