﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arbore
{
    public class heapsort
    {
        public static int nrelem = 20;
        public element[] x = new element[nrelem];
        public int n;

        //public bool relatie(){}
        //public bool schimba(){}
        //public bool propag(){}
        //public bool heapsor(){}
    }
}
