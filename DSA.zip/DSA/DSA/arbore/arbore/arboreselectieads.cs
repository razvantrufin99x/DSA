﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arbore
{
    public class arboreselectieads
    {
        public tablouinfo inf;
        public relatie rel;

        //public bool initarbsel(){}
        //public bool testarbselvid(){}
        //public bool adaugainarbsel(){}
        //public bool extragedinarbsel(){}
        //public bool radacinaarbsel(){}
        //public int nrnoduriarbsel(){}
    }
}
