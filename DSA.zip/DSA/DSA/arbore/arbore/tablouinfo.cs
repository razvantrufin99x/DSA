﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arbore
{
    public class tablouinfo
    {
        public static int nnmax = 20;
        public object[] otablouinfo = new object[nnmax + 1];
    }
}
