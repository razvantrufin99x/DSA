﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graf
{
    public class muchie
    {
        public int cost;
        public int nod1;
        public int nod2;
    }
}
