﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graf
{
    public class coadai
    {
        public static int nmaxnoduri = 20;
        public static int nmaxlegaturi = nmaxnoduri * 4;

        public int [] coada = new int [nmaxlegaturi];

        //public bool initializarecoadai( ) { }
        //public bool introduceincoada(int e ) { }
        //public bool extragedincoada( int e) { }
        //public bool testcoadagoalai( ) { }


    }
}
