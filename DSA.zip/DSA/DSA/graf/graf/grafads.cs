﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graf
{
    public class grafads
    {
        public static int nmaxnoduri = 20;
        public static int nmaxlegaturi = nmaxnoduri * 4;

        public int[] cap = new int[nmaxnoduri];
        public int[] legaturi = new int[nmaxlegaturi];
        public int nnoduri;
        public int nlegaturi;

        public int[] vizitate = new int[nmaxnoduri];
        public int[] cost = new int[nmaxlegaturi];

        public int[] apel = new int[nmaxnoduri];
        public int[] iesire = new int[nmaxnoduri];
        public int contor1;
        public int contor2;

        public int[] clasacurenta = new int[nmaxnoduri];
        public int[] minim = new int[nmaxnoduri];

        public int[] tata = new int[nmaxnoduri];

        public int[] selectate = new int[nmaxnoduri];
        public int[] distante = new int[nmaxnoduri];

        public int[,] a = new int[nmaxnoduri, nmaxnoduri];
        public int[,] p = new int[nmaxnoduri, nmaxnoduri];

        public int costminim;

        public int[,] t = new int[2, nmaxnoduri];

        public arboreselectie coadaprioritati;

        //public bool eroare(string text) { }
        //public bool exeroare(string text) { }
        //public bool aflalegaturaurmatoare(int legaturacurenta ,ref int legaturaurmatoare ) { }
        //public bool aflanod(int legaturacurenta, ref int nodcurent ) { }
        //public bool aflacap(int nod, ref int primalegatura ) { }
        //public bool aflalegatura (in dela, int la, ref int legatura ) { }
        //public bool citestegraf( ) { }

        //public bool explorareinlargime( ) { }
        //public bool explorareinadincime( ) { }
        //public bool explorarerecursiva( ) { }

        //public bool citestecosturi( ) { }
        //public bool calculdatorii( int s) { }

        //public bool explorarerecursiva1( int s) { }
        //public bool explorarerecursiva2( int s) { }
        //public bool explorarerecursiva3( int s) { }

        //public bool initdistante( int sursa) { }
        //public bool varfdistminima(ref int k) { }
        //public bool actualizeazadistante( int k) { }
        //public bool gasestecaiminime( int sursa) { }

        //public bool initaspi( ) { }
        //public bool toatedistanteminime( ) { }
        //public bool cale( int i ,int j) { }

        //public bool inchideretranzitiva( ) { }
        
        //public bool arboreminimprim(int sursa ) { }
        //public bool varfistminim(ref int k ) { }
        //public bool actualizeazadistante1(int k ) { }

        //public bool inittata( ) { }
        //public bool gasestecomponenta( int i , ref int j) { }
        //public bool uniunecomponente( int i ,  int j ) { }
        //public bool gasestelegaturaminima( ref int w , ref int u, ref int costwu) { }
        //public bool arboreminimkruskal( ) { }

        //public bool relatiecostminim(ref object p1,ref object p2 ) { }
        //public bool alcatuiestecoadapriorit( ) { }
    }
}
