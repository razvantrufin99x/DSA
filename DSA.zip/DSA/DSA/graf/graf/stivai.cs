﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace graf
{
    public class stivai
    {
        public static int nmaxnoduri = 20;
        public int[] coada = new int[nmaxnoduri];

        //public bool initializarestivai( ) { }
        //public bool introduceinstivai(int e ) { }
        //public bool extragedinstivai( ref int e) { }
        //public bool teststivagoalai( ) { }
        //public bool valoaredinvarfi( ref int e) { }
    }
}
