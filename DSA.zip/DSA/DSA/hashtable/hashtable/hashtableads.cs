﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace hashtable
{
    public class hashtableads
    {
        public static int dimensiunetabela = 256;
        public static char caracterdesfarsit = '\0';
        public static int maxlista = 1000;
        public char[] vector = new char[maxlista];
        public int urmatorul;
        public int codsir;
        public element[] tabelahash = new element[dimensiunetabela];

        //public void listeazasiruri(){}
        //public int dispersie(ref char issir){}
        //public bool onouintrare(ref char sirnou, ref element unde, ref int inceput){}
        //public bool cautare(bool introduce, ref int inceput){}
 

    }
}
