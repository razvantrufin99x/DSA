﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arbori
{
    public class Nod
    {
        public Nod st = null;
        public Nod dr = null;
        public string info;
    }
}
