﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Grafuri
{
    public class Graf
    {
        public static int nrmaxnoduri = 100;
        public static int nrmaxlegaturi = nrmaxnoduri * 20;
        public int nnoduri;
        public int nlegaturi;

        public int[] cap = new int[nrmaxnoduri];
        public int[] legaturi = new int[nrmaxlegaturi];
    }
}
