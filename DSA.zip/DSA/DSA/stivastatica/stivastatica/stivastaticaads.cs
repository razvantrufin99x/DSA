﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace stivastatica
{
    public class stivastaticaads
    {
        public int varfulstivei;
        public static int max = 1000;
        public object[] elemente = new object[max];

        //public bool initializarestiva() { }
        //public bool teststivagoala() { }
        //public bool introduceinstiva(object e) { }
        //public bool extragedinstiva(object e) { }
        //public bool valoaredinvarf(object e) { }
    }
}
