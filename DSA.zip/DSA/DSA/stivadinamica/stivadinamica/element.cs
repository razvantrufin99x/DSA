﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace stivadinamica
{
    public class element
    {
        public string valoare;
        public element precedentul;

    }
}
