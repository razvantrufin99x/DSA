﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace stivadinamica
{
    public class stivadinamicaads
    {
        public element varfulstivei;

        //public bool initializarestiva(){}
        //public bool teststivagoala(){}
        //public bool introduceinstiva(element e){}
        //public bool extragedinstiva(element e){}
        //public bool valoaredinvarf(element e){}
    }
}
