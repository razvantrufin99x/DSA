﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace multime
{
    public class multimeads
    {

        public static int maxelemente = 200;

        public object[] multime = new object[maxelemente];

        //public bool initmultimevida(){}
        //public bool tipfunc(ref object, ref object){}
        //public bool adaugaelement(ref object p){}
        //public bool extrageelement(ref object p){}
        //public bool apartine(ref object p){}
        //public bool aceleasielemente(ref object pe1, ref object pe2){}
        //public bool citesteelement(){}
    }
}
