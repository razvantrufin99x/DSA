﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace multime
{
   public  class multimea
    {
       public static int max = 200;
       public object[] multimedeobiecte = new object[max];
       public delegate bool tipfunct(object a, object b);

       
       //public bool initmultimevida() { }
        //public bool adaugaelement(object p, tipfunct egale) { }
        //public bool extrageelement(ref object p) { }
        //public bool apartine(object p, tipfunct egale) { }
        //public bool acelasi(object p1, object p2) { }
        //public bool citestemasina( ref object p) { }
        //public bool extrageelement(object p) { }

    }
}
