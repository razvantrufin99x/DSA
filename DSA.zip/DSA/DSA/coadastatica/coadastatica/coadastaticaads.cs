﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace coadastatica
{
    public class coadastaticaads
    {
        public int capulcozii;
        public int coadacozii;
        public int lungimecoada;
        public static int max = 1000;
        public object[] elemente = new object[max];

        //public bool initializarecoada(){}
        //public bool testcoadagoala(){}
        //public bool introduceincoada(object e){}
        //public bool extragedincoada(object e){}
        //public bool valoaredincap(object e){}
        //public void avans(int p){}
        //public void listeazacoada(){}


    }
}
