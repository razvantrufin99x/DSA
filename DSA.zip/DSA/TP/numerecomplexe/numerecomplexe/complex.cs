﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace numerecomplexe
{
    public class complex
    {
        public float real;
        public float imaginar;

        public void addcomplex(complex pc)
        {
            real += pc.real;
            imaginar += pc.imaginar;
        }

        public void difcomplex(complex pc)
        {
            real -= pc.real;
            imaginar -= pc.imaginar;
        }



    }
}
