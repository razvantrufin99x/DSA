﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace factorial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        //System.StackOverflowException was unhandled

          public double factorial(double x)
        {
          
                if (x == 0)
                {
                    return 1;
                }
                else
                {
                    return factorial((x - 1) * x);
                }
            
        
           
        }

          public double factorial2(int x)
          {
              double d = 0;
              for (int i = 1; i <= x; i++)
              {
                  if (x == 0)
                  {
                      return 1;
                  }
                  else
                  {
                      d = ((i - 1) * i);
                  }
              }
              return d;
          }

          private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += factorial2(3).ToString() + "\r\n"; 
        }
    }
}
