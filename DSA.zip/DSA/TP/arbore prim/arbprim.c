
#include "graf.h"
#include "costuri.h"

int cost [nmaxlegaturi];

int selectate [nmaxnoduri];
int distante [nmaxnoduri];
int tata [nmaxnoduri];
int costminim;

bool initdistante (int sursa)
{int i ,ar, cnod;
for (i= 1; i<= nnoduri;i++)
distante[ i]= -1;
if(! aflacap (surca,&arc))
eroare (lista succesori)
do{
if (!aflanod (arc ,&nod))
eroare (aflare nod)
if( nod!= 0){
distante [nod]= cost [arc];
tata [nod]!= sursa;
if (!alfalegaturaurmatoare( arc ,&arc))
eroare (gasire legatura urmatoare)
}
while (nod  !=0);
return true;
}




bool virfdistminima (int *k){
int distantaminima =-1;
int i ;
for (i=1 ;i <=nnoduri; i++)
if (distante [i]!= -1  && selectate [i]== 0)
if (distantaminima == -1 || distante[i]< distantaminima)
{
*k=i;
distantaminima = distante [i];
if(distantaminima== -1)
eroare (eroare la distanta minima)
else
return true;
}



bool actualizeazadistante1 (int k)
{
int arc ,j;
if (!alfacap( k,&arc))
eroare (aflare adiacente)
do
{
if(! aflanod (arc,&j))
eroare (aflare nod)
if( j != 0 && selectate[ j] == 0)
if (distante [j]== -1 ||
distante [j ] > cost[ arc])
{
distante [j ] = cost [arc];
tata [j]= k;
}
if (j !=0)
if (!aflalegaturaurmatoare (arc ,&arc))
eroare (legatura urmatoare)
}
while( j !=0);
return true;
}


bool arboreminimprim (int sursa)
{int i, k;
selectate [sursa] =1;
if(! initdistante (sursa))
return false;
for (i= 1; i <=nnoduri ;i++)
{if(!virfdistminima(&k ))
return false;
selctate [k]= 1;
costminim +=distante[ k];
if(!actualizeazadistante1( k))
return false;
}
}





int main(){
int i ;
citestegraf();
if(! citestecosturi())
exit (exit_failure)
for (i = 1 ;i<= nnoduri ;i++)
{
tata [i]= 0;
selectate [i]= 0;
}
costminim =0;
if (!arboreminimprim (1))
exit (exit_failure)
printf ("arbore minim are costul %d ", costminim);
printf ("muchiile sunt:");
for (i = 2 ;i <=nnoduri ;i++)
printf ("\n %d %d ,tata [i], i);
exit (exit_success)
}




























