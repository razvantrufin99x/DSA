
#include "graf.h"
#include "costuri.h"
int cost[namxlegaturi];
int selectate[nmaxnoduri];
int distante[nmaxnoduri];
int tata[nmaxnoduri];

bool initdistante(int sursa)
{int i , arc, nod;
for(i=1;i<=nnoduri;i++)
distante[i]=-1;
if(!aflacap(sursa,&arc))
eroare ( eroare lista succesori)
do{ if(!aflanod(arc,&nod))
eroare (eraore aflare nod)
if(nod!=0)
{distante[nod]= cost[arc];
tata[nod]=sursa;
if(!aflalegaturaurmatoare(arc,&arc))
eroare (legatura urmatoare)
}
}while(nod!=0);
return true;
}

bool virfdistminima(int *k)
{int distantaminima = -1;
int i ;
for(i=1;i<=nnoduri;i++)
 if(distante[i]!=-1 && selectate[i]==0)
if(distantaminima==-1||distante[i]<distantaminima)
{*k = i;
distantaminima= distante[i];
}
if(distantaminima==-1)
eroare(distanta minima)
else
return true;
}

bool actualizeazadistante(int l_
{int arc,i;
if (!aflacap(k,&arc))
eroare(aflare adiacente)
do{ if(!aflanod(arc,&j))
eroare(aflare nod)
if(j!=0 && selectate[j]==0)
if(distante[j]==-1 || distante[j] > distante[k] + cost[arc])
{distante[j] = distante[k]+cost[arc];
tata[j]=k;
}
if(j!=0)
if(!aflalegaturaurmatoare(arc,&arc))
eroare (legatura urmatoare)
}while(j!=0);
return true;
}


bool gasestemaiminime(int sursa)
{
int i , k;
selectate[sursa] = 1;
if(!initdistante(sursa))
return false;
for(i=1;i<nnoduri;i++)
 {if(!virfdistminima(&k))
return false;
selectate[k]=1;
if(!actualizeazadistante(k))
return false;
}
return true;
}

int main()
{

int i ,sursa;
citestegraf();
if(!citestecosturi())
exit(exit_failure);
printf("\n dati nodul sursa : " );
scanf("%d", &sursa);
for(i=1;i<nnoduri;i++)
{
tata[i]=0;
selectate[i]=0;
}
if(!gasestemaiminime(sursa))
exit(exit_failure);
print("\n caile minime de la %d au urmatoarele costuri :", sursa);
for(i=1;i<=nnoduri;i++)
if(!=sursa)
{printf("\n->%3d ",i);
if(distante[i]!=-1)
printf(" cost = %5d cu tatal = %5d", distante[i], tata[i]);
else
printf("este infinita");
}
exit(exit_success);
}







