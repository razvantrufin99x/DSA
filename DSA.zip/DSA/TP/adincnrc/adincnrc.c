#include "graf.h"

int vizitate[nmaxnoduri];
int apel[nmaxnoduri];
int iesire[nmaxnoduri];
int contor1,contor2;

void explorarerecusriva1(int s)
{
int w, nw;
int legaturacurenta;
vizitate[s]=1;
printf("vizitate nodurl %d\n ", s);
if(!aflacap(s,&w))
ex_eroare(aflare cap lista)
while(aflanod(w,,&nw) && nw!=0_
{if(vizitate[nw]==0)
{
contor1++;
apel[nw]=conor1;
explorarerecusriva1(nw);
contor2++;
iesire[nw]=contor2;
}
if(!aflalegaturaurmatoare(w,&w))
ex_eroare(aflae legatura);
}
if(nw!=0)
ex_eroare(aflare nod)
}


int main()
{
int start;
contor1 = contor2 = 0;
citestegraf();
for(start=1;start<=nnoduri;start++)
vizitate[start]=0;
for(start=1;start<=nnoduri;start++)
if(vizitate[start]=]0)
{
printf("\n explorare din %d\n", start);
contor1++;
apel[start]=contor1;
explorarerecursiva1(start);
contor2++;
iesire[start]=contor2;
}
printf("\n sfarsit explorare");
for(start=1;start<=nnoduri;start++)
printf("\n nod = %d apel= %d iesire = %d, start , apel[start], iesire[start]);
exit(exit_success);
}








