﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listamasini
{
    public class masina
    {
        public string masina;
        public int anfabricatie;
        public culori culoaremasina;
        public bool functioneaza;
    }
}
