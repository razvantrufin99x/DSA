﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace listamasini
{
    public enum culorile { alb ,galben , rosu, negru , albastru };
   
    public class culori
    {
        public culorile culoare;
    }
}
