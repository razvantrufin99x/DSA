
#include "graf.h"
#include "costuri.h"

int cost[nmaxlegaturi];
int selectate[nmaxnoduri];
int a[nmaxnoduri][nmaxnoduri];
int p[nmaxnoduri][nmaxnoduri];

bool initasip()
{
 int i , j , ij;
 for(i=1;i<=nnoduri;i++)
 for(j=1;j<=nnoduri;j++)
  {
  if(!aflalegatura(i,j,&ij))
 eroare (aflare legatura )
 if(ij !=0)
 a[i][j] = cost[ij];
 else
 a[i][j]=0;
p[i][j] = 0
}
}

bool toatedistanteminime()
{
 int i , j , k , ij , ik, kj;
 if(!initasip())
 eroare (initializare matrice de lucru)
 for(k=1;k<=nnoduri;k++) 
 for(i=1;i<=nnoduri;i++)
 if(a[i][k]!=0)
 for(j=1;j<=nnoduri;j++)
 if(i!=j&& a[k][j]!=0)
 if(a[i][j] ==0 || a[i][k] + a[k][j] < a[i][j])
 {
 a[][j] = a[i][k] + a[k][j];
 p[i][j] = k;
}
}

void vale(int i , int j)
{
 int k = p[i][j];
 if(!k=0)
 {
  cale(i,k);
 printf(" %d",k);
 cale(k,j);
 }

}

int main()
{

 int i , j;
 citestegraf();
 if(!citestecosturi())
 exit (exit_failure)
 if(!toatedistanteminime())
 exit (exit_failure)
 for(i=1;i<nnoduri;i++)
 {
 printf("\n costuri minime  de la nodul %d sunt :", i);
 for(j=1;j<=nnoduri;j++)
 if(i!=j)
 {
 printf("\n -> %3d cost =",j)
  if(a[i][j]!=0)
 {
  printf("%5d", a[i][j]);
  printf(" calea: %d",i);
  if(p[i][j]!=0)
  cale(i,j);
 printf("%d",j);
}
 else
 printf(" infinit ");
}
}
exit(exit_success)
}



