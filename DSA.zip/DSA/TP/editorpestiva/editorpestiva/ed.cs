﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace editorpestiva
{
    public class stiva
    {
     
    }
    
    public class pozitie
    {
        public int x;
        public int y;
    }

    public class ed
    {
        public int sfarsit = 26;
        public char cr = '\r';

        public bool gata;
        public char c;
        public pozitie pozitiecursor;
        stiva Stiva;

        public void crlf()
        {
            pozitiecursor.x = 1;
            gata = (pozitiecursor.y+1 == 26);
        }

        public void avanscursor()
        {
            if (pozitiecursor.x % 80 != 0)
                crlf();
            else
                pozitiecursor.x++;
            //textBoxEDITOR.Text += c;
        }

        public void tratareparantezadeschisa()
        {
            pozitie p;
            p = pozitiecursor;
            if (introduceinstiva(ref Stiva, ref p))
                avanscursor();
            //exit(0);
        }

        public void tratareparantezainchisa()
        {
            pozitie p;
            pozitie temp;
            if (extragedinstiva(ref Stiva, ref p))
            {
                //textBoxEDITOR.Select(1,1);
                //textBoxEDITOR.Text = "eroare !!! apsati orice tasta";
                getche();
                //textBoxEDITOR.Select(1,1);
                //textBoxEDITOR.Text = "";
                //textBoxEDITOR.Select(pozitiecursor.x, pozitiecursor.y);
            }
            else
            {
                avanscursor();
                temp = pozitiecursor;
                pozitiecursor = ref p;
                //textBoxEDITOR.Select(pozitiecursor.x, pozitiecursor.y);
                //Thread.Sleep(200);
                pozitiecursor = temp;
                //textBoxEDITOR.Select(pozitiecursor.x, pozitiecursor.y);
                p = null;
            }
        }

        public void run()
        { 
            if(!initializarestiva(ref Stiva))
                 //textBoxEDITOR.Text = "\r\n nu se poate face initializarea ";
            else
            {
                 gata = false;
                 //textBoxEDITOR.Text = "";
                 pozitiecursor.x = 1;
                 pozitiecursor.y = 2;
                 do{
                     //textBoxEDITOR.Select(pozitiecursor.x, pozitiecursor.y);
                     c = getch();
                     switch(c)
                     {
                         case '(' : tratareparantezadeschisa(); break;
                         case ')' : tratareparantezainchisa(); break;
                         case cr : crlf(); break;
                         case sfarsit : gata = true ; break;
                         default : avanscursor();
                     }
                 }while(gata==false);
                if(!teststivagoala(ref Stiva))
                {
                    //textBoxEDITOR.Text = "\r\n nu se termina cu bine ";
                    getch();
                }
            }   
        }

    }
}
