﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace editorpestiva
{
    class stiva
    {
        /*
         //stiva.h

#include <general.h>

typedef struct element
{
    pointer valoare;
    struct element * precedentul;
} element , *pelement;

typedef struct
{
 pelement virfulstivei;

}stiva , *pstiva;

bool initializarestiva(pstiva p );
bool teststivagoala(pstiva p);
bool introduceinstiva(pstiva p , pointer e);
bool extragedinstiva(pstiva p , ppointer e);
bool valoaredinvirf(pstiva p , ppointer e);

//stiva.c

#include <stiva.h>

bool initializarestiva(pstiva p)
{
    p->virfulstivei = null;
    return true;
}

bool teststivagoala(pstiva p)
{
    return p->virfulstivei == null;
}

bool introduceinstiva (pstiva ps, pointer e)
{
    pelement p;
    p = (pelement)malloc (sizeof(element));
    if(!p)
    return false;
    else
    {
        p->valoare =e;
        p-> precedentul = ps->virfulstivei;
        ps->virfulstivei = p;
        return true;
    }

}

bool extragedinstiva(pstiva p , ppointer e)
{
    pelement t;
    if(teststivagoala(p))
    return false;
    else
    {
        *e = p->virfulstivei -> valoare;
        t = p->virfulstivei - >precedentul;
        free(p->virfulstivei);
        p->virfulstivei = t;
        return true;
    }
}



         */
    }
}
