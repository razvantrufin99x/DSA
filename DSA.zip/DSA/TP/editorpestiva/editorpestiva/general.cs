﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace editorpestiva
{
    class general
    {
        /*
         //general.h

#ifndef __general
#define __general

#include <alloc.h>
#include <coion.h>
#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <dos.h>

#include <string.h>
#define bool int;
#define true 1
#define false 0

typedef void * pointer, **pointer;
typedef char * sir , ** psir;

         */
    }
}
