

//arbsel.h

#include "general.h"
#define nnmax = 20;

typedef bool(*relatie) (pointer, pointer);

typedef pointer tablouinfo[nnmax+1];
typedef struct {
tablouinfo inf;
int nn;
relatie rel;
}arboreselectie , * parbsel;

bool initarbsel(parbsel p, relatie r);
bool testarbselvid(parbsel p);
bool adaugainarbsel(parbsel p , pointer info);
bool extragedinarbsel(parbsel p , ppointer info);
bool radacinaarbsel(parbsel p , ppointer info);
int nrnoduriarbsel(parbsel p);

//arbsel.c

#include "arbsel.h"

bool initarbsel(parbsel p, relatie r)
{
p->nn=0;
p->rel = r;
return true;
}

bool testarbselvid(parbsel p)
{
return p->nn == 0;
}
bool adaugainarbsel(parbsel p , pointer info)
{
int k , tata;
if(p->nn==nnmax)
return false;
p->nn++;
k = p->nn;
while(k>1)
{tata = k/2;
if(p->rel(p->inf[tat],info))
break;
p->inf[k]=p->inf[tata];
k=tata;
}
p->inf[k]=info;
return true;
}


bool extragedinarbsel(parbsel p , ppointer info)
{
int k , urm;
if(p->nn==0)
return false;
*info = p->inf[1];
p->inf[1]=p->inf[p->nn];
k=1;
while(true)
{urm = s * k;
if(urm>=p->nn)
break;
if((urm+1)<p->nn)
if(!(p->rel(p->inf[urm],p->inf[urm+1])))
urm++;
if(p->rel(p->inf[p->nn],p->inf[urm]))
break;
p->inf[k]=p->inf[urm];
k=urm;
}
p->inf[k]=p->inf[p->nn];
p->nn--;
return true;
}


bool radacinaarbsel(parbsel p , ppointer info)
{
if(p->nn==0)
return false;
else
{
*info = p->inf[1];
return true;
}

}
int nrnoduriarbsel(parbsel p)
{
return p->nn;
}

