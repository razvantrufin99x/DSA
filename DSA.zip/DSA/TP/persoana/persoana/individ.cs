﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace persoana
{
    public class data
    {
        public int an;
        public int luna;
        public int zi;

        public data() { }
        public data(data x) { an = x.an; luna = x.luna; zi = x.zi; }
        public data(int pan, int pluna, int pzi) {  }
        public data diferenta(data x)
        {
            data temp = new data();
            temp.an = Math.Abs(x.an - an);
            temp.luna = Math.Abs(x.luna - luna);
            temp.zi = Math.Abs(x.zi - zi);

            return temp;
        }

        public string printdata(data x)
        {
            string s = "";
            s = x.an.ToString() + "," + x.luna.ToString() + "," + x.zi.ToString();
            return s;
        }
    }
    class individ
    {
        public string nume;
        public string prenume;
        public data datanasterii;
        public float inaltime;


    }

    class om : individ 
    {
    
    }

    class copil : om
    {

    }

    class persoane : om
    {

    }

    class elev : persoane
    {
    }

    class profesor : persoane
    {
    
    }

    class educator : persoane
    {

    }

    class diriginte : persoane
    {

    }

    class director : persoane
    {

    }

    class parinte : persoane
    {

    }

    class mama : parinte
    {

    }

    class tata : parinte
    {

    }

    class ruda : persoane
    {

    }

    class coleg : persoane
    {

    }

    class unghi : ruda { }
    class matusa : ruda { }
    class bunic : ruda { }
    class bunica : ruda { }
    class verisor : ruda { }
    class verosoara : ruda { }
    class stranepot : ruda { }
    class nepot : ruda { }
    class stranepoata : ruda { }
    class nepoata : ruda { }
    class strabunic : ruda { }
    class strabunica : ruda { }





}
