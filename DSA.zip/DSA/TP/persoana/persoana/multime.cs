﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace persoana
{
    public class multime
    {
        List<persoane> multimea = new List<persoane>();

    }
}
