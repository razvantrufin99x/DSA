//arbcaut.h

#include "general.h"
#include "arbore.h"

typedef bool (*relatie)(pointer, pointer);
bool inserarenod(parbore,pointer,relatie,relatie);
bool eliminanod(parbore,relatie,pointer *);
bool cautanod(parbore,pointer,relatie,relatie,parbore);
bool cautasielimina(parbore, pointer,relatie,relatie,relatie,pointer *);

//arbcaut.c

#include "arbcaut.h"
bool inserarenod*parbore prad, pointer info, relatie cheiegale, relatie cheiepred)
{arbore curent;
if(*prad == arborevid)
return construiestearbore(info,arborevid,arborevid,prad);
curent=*prad;
do{ if * cheiegale(curent->inf.info))
return false;
if(cheiepred(info,curent->inf))
if(curent->st==arborevid)
return construiestearbore(info, arborevid,arborevid,&curent->st);
else
curent = curent->st;
else
if(curent->dr==arborevid)
return construiestearbore(info,arborevid,arborevid,&curent->dr);
else
curent = curet ->dr;
}while(true);
}

bool cautanod(parbore parb, pointer info, relatie cheiegale, relatie cheiepred, parbore nodul)
{arbore curent;
*nodul = arborevid;
curent = *parb;
while(curent!=arborevid)
{if(cheiegale(curent->inf.info))
{*nodul = curent;
curent = arborevid;
}
else if)cheiepred(info,curent->inf))
curent = curent->st;
else
curent = curent->dr;
}
return *nodul!=arborevid;
}

bool eliminanod(parbore el, relatie r, pointer *infelim)
{arbore elimina, tatapivot;
if(*el==aborevid)
return false;
else
{eliminat = *el;
*infelim = (*el)->inf;
if((*el)->st==arborevid)
*el (*el)->dr;
else if((*el)->dr == arborevid)
 *el = (*el)->st;
else
{if(r((*rl)->st,(*el)->dr))
if((*el)->st->dr == arborevid)
{eliminat = (*el)->st;
(*el)->st = eliminat ->st;
}
else
{
tatapivot = (*el)-st;
while(tatapivot->dr->dr!=arborevid)
tatapivot = tatapivot ->dr;
eliminat = tatapivot->dr;
tatapivot ->dr = eliminat->st;
}
else
if((*el)->dr->st==arborevid)
{eliminat = (*el)->dr;
(*el)->dr = eliminat ->dr;
}
else
{
tatapivot=(*el)->dr;
while(tatapivot->st->st!=arborevid)
tatapivot = tatapivot ->st;
eliminat = tatapivot->st;
tatapivot->st=eliminat->dr;
}
(*el)->inf=eliminat->inf;
}
free(eliminat);
return true;
}
}

bool cautare(parbore pcurent, relatie cheiegale, relatie cheiepred, relatie r, pointer info, pointer *infelim)
{
inf((*pcurent)==arborevid)
return false;
else if(cheiegale(info,(*pcurent)->inf))
return eliminanod(pcurent, r, infelim);
else if(cheiepred(info,(*pcurent)->inf))
 return cautare(&(*pcurent)->st, cheiegale, cheiepred, r , info, infelim);
else return cautare(&(*pcurent)->dr, cheiegale, cheiepred, r, info, infelim);
}


bool cautaresielimia(parbore parb, pointer info, relatie r, relatie cheiegale, relatie cheiepred, pointer * infelim)
{
*infelim = null;
return cautare(parb,cheiegale,cheiepred, r , info, infelim);
}




