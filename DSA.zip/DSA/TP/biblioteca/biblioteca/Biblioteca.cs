﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace biblioteca
{

    public class coada
    { 
    
    
    }
    
    
    public class Biblioteca
    {
        public int i = 0;
        public string nume;
        public string p;
        coada Coada;

        if(initializarecoada(ref coada))
        {
        //print \n nu se poate face initializarea !!!
        
        }
        else
        {
         // print \n introduceti comenzi : \n >
        do
    {
        if(kbhit())
    {
        gets(nume);
        //print >
        if(nume.length !=0)
    {
        p = nume;
        if(!p)
    {
        //print \n eroare
        //print  de alocare !!!
        //exit(0)
    }
        p = nume;
        if(!introducetiincoada(ref coada, ref p)
            //print \n nu maeste loc !!!
            break;
    }
}
else
{
if(extragedincoada(ref Coada, ref p))
trateazacererea(p);
}
}while(true);
}
}



    }
}
