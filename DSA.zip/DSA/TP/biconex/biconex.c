
#include "graf.h"

int vizitate[nmaxnoduri];
int clasacurenta[nmaxnoduri];
int apel[nmaxnoduri];
int minim[nmaxnduri];
int tata[nmaxnoduri];
int contor1;

void explorarerecursiva3(int s)
{
int w,nw,i;
int legaturacurenta;
minim[s]=apel[s];
vizitate[s]=1;
if(!aflacap(s,&w))
ex_eroare(aflare cap lista)
while(aflanod(w,&nw( && nw!=0)
{
if(vizitate[nw]==0)
{ clasacurenta[nw]=1;
contor1++;
apel[nw] = contor1;
tata[nw]=s;
explorarerecursiva2(nw);
if(minim[nw]<minim[s])
minim[s]=minim[nw];
}
if(apel[nw]<apel[s])
if(apel[nw]<minim[s])
minim[s]=apel[nw];
if(!aflalegaturaurmatoare(w,&w))
ex_eroare(aflare legatura)
}
if(nw!=0) ex_eroare(aflare nod)
if(apel[s] >= 2 && minim[s] == apel[tata[s]])
{printf("\n componenta cu centrul %d \n", s);
printf("%d", tata[s]);
for(i=1;i<=nnoduri;i++)
if(apel[i]>=apel[s]&&clasacurenta[i]==1)
{printf("%d",i);
clasacurenta[i]=0;
}
}
}

int main()
{
int start;
conto1=0;
citestegraf();
for(start=1;i<=nnoduri;start++)
{vizitate[start]=0;
clasacurenta[start]=0;
tata[start]=0;
}
for(start=1;start<=nnoduri;start++)
if(vizitate[start]==0)
{
printf("\n exploarre din %d\n, start");
clasacurenta[start]=1;
contor1++;
apel[start]=contor1;
explorarerecursiva3(start);
}
printf("sfarsit explorare");
exit(exit_success);
}




















