
#include "graf.h"
#include "costuri.h"
#include "arbsel.h"

int cost[nmaxlgaturi];
int selectate[nmaxlegaturi];
int tata[nmaxnoduri];
int costminim;
int t[2][nmaxnoduri];

typedef struct {
 int cost;
 int nod1;
 int nod2;
 } muchie , *p_muchie;

arboreselectie coadaprioritati;

bool relatiecostminim(pointer p1, pointer p2)
{
 return ((p_muchie)p1)->cost <= ((p_muchie(p2)->cost;
}

bool alcatuiestecoadapriorit()
{
int i ,arc, nod;
p_muchie temp;
initarbsel(&coadaprioritati, reletiecostminim);
for(i=1;i<=nnoduri;i++)}
if(!aflacap(i,&arc))
 eroare(eroare lista succesori)
do
{ if(!aflanod(arc,&nod))
 eroare(afla nod)
 if(nod!=0)
 {if(!(temp=(p_muchie) malloc (sizeof(muchie))))
 eroare (alocare)
else
{temp ->cost = cost[arc];
temp->nod1 = i;
temp->nod2 = nod;
if(!adaugaarbsel
(&coadaprioritati, temp))
eroare (inserare coada prioritati)
if(!aflalegaturaurmatoare(arc,&arc))
 eroare
(gasire legatura urmatoare)
}
}
}while (nod!=0);
}
return true;
}


bool inittata()
{
 int i;
 for(i = 1; i<= nnoduri; i++) tata[i]=-1;
return true;
}


bool gasirecomponenta(int i ,int *j)
{
 if(i<=0 || i>nnoduri)
 return false;
 while(tata[i]>0)
 i = tata[i];
 *j = i;
 return true;
}

bool uniunecomponente(int i, int j)
{
 int k ;
if(i<=0 || i> nnoduri ||
j<=0 || j>nnoduri)
return false;
k = tata[i]+tata[j];
if(tata[i]>tata[j])
{ tata[i]=j;
 tata[j]=k;
}
else
{
 tata[j]=i;
 tata[i]= k;
}
return true;
}

bool arboreminimkruskal()
{
 p_muchie adrtemp;
int i =1;
int w,u,constwu;
int compw, compu;
if(!inittata())
eroare(initializare tablou componente)
while(i<nnoduri && extragedinarbsel(&coadaprioritati,(ppointer)&adrtemp))
{
w = adrtemp -> nod1;
u = adrtemp->nod2;
costwu = adrtemp -> cost;
if(!gasestecomponenta(w,&compw))
eroare(calcul componenta)
if(!gasestecomponenta(u,&compu))
eroare(calcul componenta)
if*compw != compu){
 tata[0][i] = w;
 tata[1][i] = u;
 costminim += costwu;
if(!uniunecomponente(compw,compu))
 eroare (reuniune componente)
i++;
}
}
if(i<nnoduri-1)
eroare (nu exista arbore de acoperire)
else
return true;
}

int main()
{
int i;
citestegraf();
if(!citestecosturi())
 exit(exit_failure)
for(i=1;i<=nnoduri;i++)
{selectate[i]=0;
t[0][i] = t[1][i] = 0;
}
costminim = 0;
if(!alcatuiestecoadapriorit())
 exit(exit_failure)
if(!(arboreminimkruskal))
 exit(exit_failure)
printf("\n arborele minim are costul : %d", costminim);
printf("\nmuchiile sunt:");
for(i=1;i<nnoduri;i++)
printf("\n %d %d", t[0][j], t[1][i]);
 exit(exit_success)
}




