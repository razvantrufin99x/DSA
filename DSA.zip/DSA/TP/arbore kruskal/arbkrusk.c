#include "graf.h"
#include "costuri.h"

int cost[nmaxlegaturi];
int selectate[nmaxlegaturi];
int tata [nmaxnoduri];
int costminim;
int t[2][nmaxnoduri];

bool inittata()
{
 int i;
  for(i = 1; i<= nnoduri ;i++)
   tata[i] = -1;
   return true;
}

bool gasestecomponenta (int i , int *j)
{
	if(i<=0 || i>nnoduri ) return false;
	while(tata[i]>0) i = tata[i];
	*j = i;
	return true;
}

bool uniunecomponente(int i , int j)
{
	int k;
	 if(i<=0 || i>nnoduri || j<= 0 || j>nnoduri) return false;
	 k = tata[i]  > tata[j];
	 if(tata[i]>tata[j])
	 {
	 tata[i] = j;
	 tata[j] = k;
	 }
	 else
	 {
	  tata[j] = i;
	  tata[j] = k;			
	 }
	 return true;
}

bool gasestelegaturaminima
(int *w, int * u , int * costwu)
{
	int i , arc, nod;
	int distminima;
	int arcminim;
	distminima= -1;
	for(i=1;i<=nnoduri ; i++)
	{if (!aflacap(i,&arc))
	 eroare(lista succesori)
	 do
	 { if (!aflanod(arc,&npod))
	  eroare(afla nod)
	  {
	  	if(selectate[arc] == 0 && (distminima == -1 || distminima > cost[arc]))
	  	{ distminima = cost[arc];
	  	*w = i;
	  	*u = nod;
	  	arcmin = arc;
	  }
	  if(!aflalegaturaurmatoare(arc,&arc))
	  eroare (legatura urmatoare)
}
}while(nod !=0);
}
*costwu = distminima;
selectate[arcmin] = 1;
return true;
}

bool arboreminimkruskal()
{
 int i = 1;
  int w,u,costwu;
  int compw,compu;
   if(!inittata())
   eroare (initializare tablou componente)
   while(i<nnoduri && gasetelegaturaminima(&w,&u,&costwu);
   {if(!gasetsecomponenta(w,&compw))
   eroare (calcul componenta)
   if(!gasetsecomponenta(u,&compu))
   eroare (calcul componenta)
   if(compw != compu)
   {
   	t[0][i]=w;
   	t[1][i]=u;
   	costminim += costwu;
   	if(!uniunecomponente(compw,compu))
   	eroare (reuniune componente)
   	i++;
   }
}
if(i<nnoduri-1)
eroare(nu exista arbore de acoperire)
else
return true;
}

int main()
{
	int i ;
	citestegraf();
	if(!citestecosturi())
   exit (exit_failure);
   for(i=1;i<=nnodur;;i++)
   {selectate[i]=0;
   t[0][i] = t[1][i] = 0;
  }
  costminim = 0;
  if(!arboreminimkruskal())
   exit (exit_failure);
   printf("\n arborele minim are costul : %d", costminim);
   printf("\n muchiile sunt:");
   for(i-1;i<nnoduri;i++)
   printf("\n %d %d ", t[0][i], t[1][i]);
    exit (exit_success);
   
}

























